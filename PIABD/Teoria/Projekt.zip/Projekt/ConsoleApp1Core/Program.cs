﻿using System;
using System.Text;
//using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace SqlServerSample
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Build connection string
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "localhost";   // update me
                builder.UserID = "sa";              // update me
                builder.Password = "praktyka";      // update me
                builder.InitialCatalog = "Northwind";
                builder.Encrypt = false;
                //builder.TrustServerCertificate = true;
                // Connect to SQL
                Console.Write("Connecting to SQL Server ... ");
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();
                    Console.WriteLine("Done.");

                    // READ DBCC useroptions
                    Console.WriteLine("Set and Reading data from command DBCC useroptions, press any key to continue...");
                    Console.ReadKey(true);
                    String sql = "SET NOCOUNT OFF; " +
                        "SET LOCK_TIMEOUT 1000; " +
                        "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;" +
                        "SET QUOTED_IDENTIFIER ON";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Done.");
                    }

                    sql = "DBCC useroptions;";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("{0} : {1}", reader.GetString(0), reader.GetString(1));
                            }
                        }
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("All done. Press any key to finish...");
            Console.ReadKey(true);
        }
    }
}